﻿/*==================================================
 *  Common localization strings
 *==================================================
 */

Timeline.strings["zh"] = {
    wikiLinkLabel:  "讨论"
};

